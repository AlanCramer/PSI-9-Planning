require 'configatron'

# URL of IntelliiStore 
# configatron.url              = 'http://dev1.intellifylearning.com'
configatron.url              = 'https://hmh2.intellifylearning.com'
configatron.learningeventURI = '/v1custom/eventdata'
configatron.describeURI      = '/v1custom/entitydata'


#r180u tot on localhost or dev1
configatron.startTimeEpochInSeconds = 1430746959000; # defaults to NOW if set to zero
configatron.endTimeEpochInSeconds   = 0; # defaults to start + 1 hour if set to zero
configatron.minThinkTimeInSeconds   = 420000; # defaults to 20 seconds if set to zero
configatron.maxThinkTimeInSeconds   = 3300000; # defaults to 60 seconds if set to zero

# localhost long to double
configatron.entity.apiKey      = 'yScTs-BpQVaSg0PIlDlfzw'
configatron.entity.il_sensorId = 'com.scholastic.slms.dev1'

configatron.event.apiKey      = 'yScTs-BpQVaSg0PIlDlfzw'
configatron.event.il_sensorId = 'com.scholastic.sri.dev1'

configatron.event.sri.il_sensorId = 'com.scholastic.sri.dev1'
configatron.event.spi.il_sensorId = 'com.scholastic.spi.dev1'
