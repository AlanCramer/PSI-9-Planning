require 'configatron'
require 'json'
require 'rest_client'
require './config-hmhperf.rb'
# require './config-localhost.rb'
require 'date' 

start = Time.now

puts "Generating events"

batch_file = ARGV[0]
site_id = ARGV[1]
first = ARGV[2]
last = ARGV[3]

doit = false
saveit = true
verbose = false

puts "apiKey: #{configatron.apiKey}"
puts "server: #{configatron.url}"
puts configatron.il_sensorId

# puts "help"

file   = File.read('./event.data.json.template')
$event_template = JSON.parse(file)
file = File.read('event.json.template')
$fullEventTemplate = JSON.parse(file)
file = File.read('entity-student-template.json')
$studentTemplate = JSON.parse(file)
file = File.read('entity-enrollment-template.json')
$enrollmentTemplate = JSON.parse(file)
file = File.read('entity-class-template.json')
$classTemplate = JSON.parse(file)
file = File.read('entity-school-template.json')
$schoolTemplate = JSON.parse(file)

startTime    = (Time.now.to_i)

endTime      = startTime + 60*60  # one hour
minThinkTime = 200 # seconds
maxThinkTime = 600 # seconds

sensorId = configatron.il_sensorId;

startTime    = configatron.startTimeEpochInSeconds unless configatron.startTimeEpochInSeconds == 0
endTime      = configatron.endTimeEpochInSeconds   unless configatron.endTimeEpochInSeconds    == 0
minThinkTime = configatron.minThinkTimeInSeconds   unless configatron.minThinkTimeInSeconds    == 0
maxThinkTime = configatron.maxThinkTimeInSeconds   unless configatron.maxThinkTimeInSeconds    == 0

# puts "Generating event for time range:
#         Start Time = #{Time.at(startTime).strftime("%H:%M:%S on %m-%d-%y")}
#         End Time = #{Time.at(endTime).strftime("%H:%M:%S on %m-%d-%y")}"

# set initial timestamp to configured startTime
$timestamp = startTime

DateTime.strptime("1318996912",'%s')
job_id = 0;

theDate = Time.at($timestamp/1000).to_datetime


## Should Skip wday => Zero (0) Sunday and Six (6) Saturday.
# puts "time as date #{theDate} and #{theDate.wday} + "

## One Day is 86400000 , Add this to increment a day to timestamp

#puts "doing these: #{configatron.studentIds}"

attempt = 51000

maxScore = 30

testLevels = ['A','B','C']
testStages = ['A','B']
$grades = ['PK','K','1','2','3','4','5','6','7','8','9','10','11','12']
$siteId = site_id
$schoolId = "SCHOOL-"+rand(100000..2000000).to_s

def create_class (schoolId, classNum)
  word1 = RestClient.get 'http://randomword.setgetgo.com/get.php', :content_type => :json, :accept => :json
  word2 = RestClient.get 'http://randomword.setgetgo.com/get.php', :content_type => :json, :accept => :json

  $classId = 'class-' + classNum.to_s.rjust(8, '0')
  grade = $grades[rand(1..14)]

	vals = {
		:apiKey => configatron.apiKey,
		:siteId => "#{$siteId}",
		:schoolId => "#{schoolId}",
		:il_sensorId => configatron.il_sensorId,
		:sensorId => configatron.il_sensorId,
		:classId => $classId,
		:className => word1 + " " + word2
	}
	base = $fullEventTemplate;
	base['entity'] = $classTemplate['entity']
	klass = eval((base.inspect % vals))

	klass['timestamp'] = $timestamp * 1000
	# //puts "class #{klass}"
	return klass
end

def create_student (personNum, classId)
  user = RestClient.get 'https://randomuser.me/api/', :content_type => :json, :accept => :json
  userJ = JSON.parse( user ) 
  result = userJ['results'][0] 
  first = result['name']['first']
  last = result['name']['last']

  $personId = 'person-' + personNum.to_s.rjust(8, '0')
  grade = $grades[rand(1..14)]

	vals = {
		:apiKey => configatron.apiKey,
		:siteId => "#{$siteId}",
		:il_sensorId => configatron.il_sensorId,
		:sensorId => configatron.il_sensorId,
		:personId => $personId,
		:classId => $clasId,
		:studentId => $personId,
		:first => first,
		:last => last,
		:grade => grade,
		:role => "Student"
	}
	base = $fullEventTemplate;
	base['entity'] = $studentTemplate['entity']
	person = eval((base.inspect % vals))

	person['timestamp'] = $timestamp * 1000
	# puts "STUDENT #{person}"
	return person
end

def create_teacher (personNum, classId)
	person = create_student personNum, classId
	person['role'] = 'Teacher'
	# puts "TEACHER #{person}"
	return person
end

def create_school
  name = RestClient.get 'http://randomword.setgetgo.com/get.php', :content_type => :json, :accept => :json

	vals = {
		:apiKey => configatron.apiKey,
		:siteId => "#{$siteId}",
		:il_sensorId => configatron.il_sensorId,
		:sensorId => configatron.il_sensorId,
		:schoolId => name + "_" + rand(1000..9000).to_s,
		:name => name
	}
	base = $fullEventTemplate;
	base['entity'] = $schoolTemplate['entity']
	enroll = eval((base.inspect % vals))

	enroll['timestamp'] = $timestamp * 1000
	# // puts "SCHOOL #{enroll}"
	return enroll
end


def enrollment (personId, classId, role)

	vals = {
		:apiKey => configatron.apiKey,
		:siteId => "#{$siteId}",
		:il_sensorId => configatron.il_sensorId,
		:sensorId => configatron.il_sensorId,
		:classId => classId,
		:studentId => personId,
		:role => role
	}
	base = $fullEventTemplate;
	base['entity'] = $enrollmentTemplate['entity']
	enroll = eval((base.inspect % vals))

	enroll['timestamp'] = $timestamp * 1000
	# puts "ENROLL #{enroll}"
	return enroll
end

# configatron.studentIds.each do |personId|
# create a class
classLimit = rand(15..80)
classCount = classLimit
rosterLimit = rand(8..60)
rosterSize = rosterLimit
teacherNum = 2000
classes = [];
$schoolId = ""
students = []
enrollments = []


fB = File.open("#{batch_file}.json","w")


allTheThings = []


# for personNum in 2000..11999
for personNum in first..last
  $timestamp = startTime
  $personId = ""
  classId = ""
  elapsedDays = 0
  if classCount >= classLimit then
  	school = create_school
	if doit then
		response = RestClient.post configatron.url + configatron.describeURI, school.to_json, :content_type => :json, :accept => :json
		# puts response.to_str
	end
	if saveit then 
	  fB.puts(school.to_json)
	end
	$schoolId = school['_id']
	classCount = 0
  end
  if rosterSize == rosterLimit then

	# vals = {
	# 	:apiKey => configatron.apiKey,
	# 	:siteId => "#{$siteId}",
	# 	:il_sensorId => configatron.il_sensorId,
	# 	:sensorId => configatron.il_sensorId,
	# }

	# base = $fullEventTemplate;
	# base['entity'] = students
	# allStudents = eval((base.inspect % vals))
	studentsWrapper = { :entityData => students }

	if verbose then
		puts "STUDENTS: " + studentsWrapper.to_json
	end
	if doit && students.length > 0 then
		response = RestClient.post configatron.url + configatron.describeURI + "/batch", studentsWrapper.to_json, :content_type => :json, :accept => :json
		# puts response.to_str
	end
	if saveit && students.length > 0 then 
	  fB.puts(studentsWrapper.to_json)
	end

	# base = $fullEventTemplate;
	# base['entity'] = enrollments
	# allEnrollments = eval((base.inspect % vals))

	enrollmentsWrapper = { :entityData => enrollments }
	if verbose then
		puts "ENROLLMENTS: " + enrollmentsWrapper.to_json
	end
	if doit  && enrollments.length > 0 then
		response = RestClient.post configatron.url + configatron.describeURI + "/batch", enrollmentsWrapper.to_json, :content_type => :json, :accept => :json
		# puts response.to_str
	end
	if saveit && students.length > 0 then 
	  fB.puts(enrollmentsWrapper.to_json)
	end

	students = []
	enrollments = []

  	rosterSize = 0
  	rosterLimit = rand(15..90)
  	classNum = rand(1000000...3000000)
	classes.push(classNum)
	klass = create_class $schoolId, classNum
	if doit then
		response = RestClient.post configatron.url + configatron.describeURI, klass.to_json, :content_type => :json, :accept => :json
		# puts response.to_str
	end
	if saveit then 
	  fB.puts(klass.to_json)
	end
	# classId = klass['@id']
	classCount = classCount + 1
  end
  if rosterSize == 0 then
  	rosterSize = rosterSize + 1
  	teacherNum = teacherNum + 1
  	teacher = create_teacher teacherNum, $classId
  	students.push(teacher)
  	enroll = enrollment $personId, $classId, 'Teacher'
  	enrollments.push(enroll)

  end
  if rosterSize > 0 then 
  	rosterSize = rosterSize  + 1
  	student = create_student personNum, $classId
  	students.push(student)
  	enroll = enrollment $personId, $classId, 'Student'
	enrollments.push(enroll)

	for attempt in 1..0
		# puts "generating events for Student id #{$personId}"
		# make a student

		vals = {
			:personId => $personId,
			:apiKey => configatron.apiKey,
			:il_sensorId => sensorId,
			:sensorId => sensorId,
			:attempt => attempt,
			:assignable => "1122334456_bette_" + attempt.to_s,
			:assignableName => "The Bette (" + attempt.to_s + "th) Test",
			:testLevel => testLevels[rand(0..2)],
			:testStage => testStages[rand(0..1)],
			:classId => $classId,
			:studentId => $personId,
			:firstName => first,
			:lastName => last,
			:grade => grade,
			:role => "Student"
		}

		$timestamp = startTime + (86400000 * elapsedDays)
		elapsedDays = elapsedDays + 28

		base = fullEventTemplate;
		base['event'] = event_template['event']
		parsed_event = eval((base.inspect % vals))

		parsed_event['timestamp'] = $timestamp * 1000
		parsed_event['event']['object']['startedAtTime'] = $timestamp * 1000
		parsed_event['event']['object']['dateCreated'] = $timestamp * 1000
		parsed_event['event']['generated']['startedAtTime'] = $timestamp * 1000
		testScore = rand(0-30)
		perc = testScore / 30.0 * 100
		parsed_event['event']['generated']['percentageScore'] = perc.to_i
		parsed_event['event']['generated']['rawPoints'] = testScore
		parsed_event['event']['generated']['maxPoints'] = 30

		# puts "started: #{parsed_event.to_json}"

		if doit then
			response = RestClient.post configatron.url + configatron.learningeventURI, parsed_event.to_json, :content_type => :json, :accept => :json
			# puts response.to_str
		end
		# if saveit then 
		#   f.puts(parsed_event.to_json)
		#   f.puts(",")
		# end
	end
  end
end

puts "=================== #{start} #{Time.now}: Done "

